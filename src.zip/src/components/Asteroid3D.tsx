import { useRef, useMemo, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars, Line, Html } from "@react-three/drei";
import * as THREE from "three";

// ================= PLANETS =================
const PLANETS = [
  { name: "Mercury", size: 0.08, orbit: 2, speed: 1.6, color: "#b1b1b1" },
  { name: "Venus", size: 0.12, orbit: 3, speed: 1.2, color: "#e6c27a" },
  { name: "Earth", size: 0.13, orbit: 4, speed: 1.0, color: "#2e86ff" },
  { name: "Mars", size: 0.1, orbit: 5, speed: 0.8, color: "#ff4d2e" },
  { name: "Jupiter", size: 0.35, orbit: 7, speed: 0.3, color: "#d2b48c" },
  { name: "Saturn", size: 0.3, orbit: 9, speed: 0.2, color: "#f5deb3" },
];

// ================= ASTEROID NAMES =================
const ASTEROID_NAMES = [
  "Ceres","Vesta","Pallas","Hygiea","Eros","Psyche","Bennu","Ryugu",
  "Itokawa","Apophis","Icarus","Juno","Davida","Iris","Europa",
  "Hektor","Interamnia","Melpomene","Fortuna","Astraea",
];

// ================= SUN =================
function Sun() {
  const ref = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (ref.current) ref.current.rotation.y += 0.0005;
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.7, 128, 128]} />
      <meshStandardMaterial
        color="#ffae00"
        emissive="#ffae00"
        emissiveIntensity={6}
        roughness={0.2}
        metalness={0}
      />
      <pointLight intensity={4} distance={100} decay={2} />
    </mesh>
  );
}

// ================= PLANET =================
function Planet({ name, size, orbit, speed, color }: any) {
  const ref = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const phase = useMemo(() => Math.random() * Math.PI * 2, []);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime() * speed + phase;
    ref.current!.position.x = Math.cos(t) * orbit;
    ref.current!.position.z = Math.sin(t) * orbit;
    ref.current!.rotation.y += 0.001;
  });

  return (
    <mesh
      ref={ref}
      castShadow
      receiveShadow
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <sphereGeometry args={[size, 64, 64]} />
      <meshStandardMaterial
        color={color}
        roughness={0.6}
        metalness={0.05}
      />

      {/* Atmosphere glow */}
      {name === "Earth" && (
        <mesh scale={1.08}>
          <sphereGeometry args={[size, 64, 64]} />
          <meshBasicMaterial color="#4da6ff" transparent opacity={0.15} />
        </mesh>
      )}

      {hovered && (
        <Html distanceFactor={10}>
          <div style={{
            color: "white",
            fontSize: "12px",
            background: "rgba(0,0,0,0.6)",
            padding: "4px 8px",
            borderRadius: "6px",
            fontFamily: "monospace"
          }}>
            {name}
          </div>
        </Html>
      )}
    </mesh>
  );
}

// ================= ORBIT RING =================
function OrbitRing({ radius }: any) {
  const points = useMemo(() => {
    return Array.from({ length: 300 }, (_, i) => {
      const a = (i / 300) * Math.PI * 2;
      return new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius);
    });
  }, [radius]);

  return <Line points={points} color="#ffffff15" lineWidth={1} />;
}

// ================= ASTEROID =================
function Asteroid({ name, position }: any) {
  const ref = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  return (
    <mesh
      ref={ref}
      position={position}
      scale={0.07}
      castShadow
      receiveShadow
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <dodecahedronGeometry args={[1, 1]} />
      <meshStandardMaterial
        color="#6f6f6f"
        roughness={1}
        metalness={0.1}
      />

      {hovered && (
        <Html distanceFactor={8}>
          <div style={{
            color: "white",
            fontSize: "11px",
            background: "rgba(0,0,0,0.7)",
            padding: "3px 6px",
            borderRadius: "5px",
            fontFamily: "monospace"
          }}>
            ☄ {name}
          </div>
        </Html>
      )}
    </mesh>
  );
}

// ================= ASTEROID BELT =================
function AsteroidBelt() {
  const asteroids = useMemo(() => {
    return Array.from({ length: 100 }).map((_, i) => {
      const angle = Math.random() * Math.PI * 2;
      const radius = 5.8 + Math.random() * 2.5;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = (Math.random() - 0.5) * 0.25;

      return {
        name: ASTEROID_NAMES[i % ASTEROID_NAMES.length],
        position: [x, y, z],
      };
    });
  }, []);

  return (
    <>
      {asteroids.map((a, i) => (
        <Asteroid key={i} name={a.name} position={a.position} />
      ))}
    </>
  );
}

// ================= MAIN =================
export default function SolarSystem() {
  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <Canvas
        shadows
        camera={{ position: [0, 8, 16], fov: 45 }}
      >
        <color attach="background" args={["#01020a"]} />

        <Stars radius={300} depth={80} count={12000} factor={4} fade />

        {/* LIGHTING */}
        <ambientLight intensity={0.15} />
        <directionalLight
          position={[5, 5, 5]}
          intensity={0.4}
          castShadow
        />

        {/* SUN */}
        <Sun />

        {/* PLANETS */}
        {PLANETS.map((p) => (
          <group key={p.name}>
            <OrbitRing radius={p.orbit} />
            <Planet {...p} />
          </group>
        ))}

        {/* ASTEROIDS */}
        <AsteroidBelt />

        <OrbitControls
          enableZoom
          enableRotate
          enablePan
          dampingFactor={0.05}
        />
      </Canvas>
    </div>
  );
}
