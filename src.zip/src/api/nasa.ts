import axios from 'axios';
import { format, addDays } from 'date-fns';

const API_KEY = import.meta.env.VITE_NASA_API_KEY || 'DEMO_KEY';
const BASE_URL = 'https://api.nasa.gov/neo/rest/v1';

export interface Asteroid {
  id: string;
  name: string;
  is_potentially_hazardous_asteroid: boolean;
  absolute_magnitude_h: number;
  estimated_diameter: {
    kilometers: {
      estimated_diameter_min: number;
      estimated_diameter_max: number;
    };
  };
  close_approach_data: Array<{
    close_approach_date: string;
    close_approach_date_full: string;
    epoch_date_close_approach: number;
    relative_velocity: {
      kilometers_per_second: string;
      kilometers_per_hour: string;
      miles_per_hour: string;
    };
    miss_distance: {
      astronomical: string;
      lunar: string;
      kilometers: string;
      miles: string;
    };
    orbiting_body: string;
  }>;
  orbital_data?: any;
  // Custom properties for our app
  risk_score: number;
  risk_level: 'Low' | 'Medium' | 'High';
}

function calculateRisk(asteroid: any): { score: number; level: 'Low' | 'Medium' | 'High' } {
  let score = 0;
  
  // Factor 1: Hazardous flag (+40 points if true)
  if (asteroid.is_potentially_hazardous_asteroid) {
    score += 40;
  }
  
  // Factor 2: Size (Max +30 points)
  const avgDiameter = (asteroid.estimated_diameter.kilometers.estimated_diameter_min + asteroid.estimated_diameter.kilometers.estimated_diameter_max) / 2;
  // Typical asteroid is ~0.1km. Scale up to 1km = 30 points
  score += Math.min(30, avgDiameter * 30);
  
  // Factor 3: Miss Distance (Max +30 points)
  const closeApproach = asteroid.close_approach_data[0];
  if (closeApproach) {
    const missDistLunar = parseFloat(closeApproach.miss_distance.lunar);
    // 0 lunar distance = 30 points, > 50 lunar distances = 0 points
    score += Math.max(0, 30 - (missDistLunar / 50) * 30);
  }
  
  score = Math.round(score);
  
  let level: 'Low' | 'Medium' | 'High' = 'Low';
  if (score >= 65) level = 'High';
  else if (score >= 35) level = 'Medium';
  
  return { score, level };
}

export const fetchNeoFeed = async (): Promise<Asteroid[]> => {
  const startDate = format(new Date(), 'yyyy-MM-dd');
  // NASA NeoWs feed max limit is 7 days
  const endDate = format(addDays(new Date(), 7), 'yyyy-MM-dd');

  try {
    const response = await axios.get(`${BASE_URL}/feed`, {
      params: {
        start_date: startDate,
        end_date: endDate,
        api_key: API_KEY,
      },
    });

    const nearEarthObjects = response.data.near_earth_objects;
    const allAsteroids: Asteroid[] = [];

    // Flatten the date-indexed object into a single array
    Object.keys(nearEarthObjects).forEach((date) => {
      nearEarthObjects[date].forEach((ast: any) => {
        const risk = calculateRisk(ast);
        allAsteroids.push({
          ...ast,
          risk_score: risk.score,
          risk_level: risk.level,
        });
      });
    });

    // Sort by risk score descending
    return allAsteroids.sort((a, b) => b.risk_score - a.risk_score);
  } catch (error) {
    console.error('Error fetching NASA NEO Feed:', error);
    throw error;
  }
};

export const fetchAsteroidDetails = async (id: string): Promise<Asteroid> => {
  try {
    const response = await axios.get(`${BASE_URL}/neo/${id}`, {
      params: { api_key: API_KEY },
    });
    const ast = response.data;
    const risk = calculateRisk(ast);
    return {
      ...ast,
      risk_score: risk.score,
      risk_level: risk.level,
    };
  } catch (error) {
    console.error(`Error fetching asteroid ${id}:`, error);
    throw error;
  }
};
